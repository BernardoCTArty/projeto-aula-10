var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ball1 = createSprite(50,50,50,50);
var ball2 = createSprite(395,395,30,30);
var ball3 = createSprite(200,200,70,70);
var ball4 = createSprite(350,50,100,100);
var ball5 = createSprite(50,350,120,120);
var ball6 = createSprite(350,200,140,140);
ball1.velocityX = -5;
ball1.velocityY = -5;

ball2.velocityX = -5;
ball2.velocityY = -5;

ball3.velocityX = -5;
ball3.velocityY = -5;

ball4.velocityX = -5;
ball4.velocityY = -5;

ball5.velocityX = -5;
ball5.velocityY = -5;

ball6.velocityX = -5;
ball6.velocityY = -5;

function draw() {
  
  background("white");
  
  createEdgeSprites();
  
  ball1.bounceOff(edges);
  ball2.bounceOff(edges);
  ball3.bounceOff(edges);
  ball4.bounceOff(edges);
  ball5.bounceOff(edges);
  ball6.bounceOff(edges);
  
  ball1.bounce(ball2);
  ball3.bounce(ball1);
  ball3.bounce(ball2);
  ball4.bounce(ball1);
  ball4.bounce(ball2);
  ball4.bounce(ball3);
  ball5.bounce(ball1);
  ball5.bounce(ball2);
  ball5.bounce(ball3);
  ball5.bounce(ball4);
  ball6.bounce(ball1);
  ball6.bounce(ball2);
  ball6.bounce(ball3);
  ball6.bounce(ball4);
  ball6.bounce(ball5);
  
  ball1.shapeColor = "red";
  
  ball2.shapeColor = "black";
  
  ball3.shapeColor = "blue";
  
  ball5.shapeColor = "green";
  
  ball6.shapeColor = "orange"
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
